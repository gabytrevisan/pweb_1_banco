<?php

include "./paginas/aula03_funcao.php";

head();

echo "<h3>Sistema Academico</h3>";
echo "<a href='http://www.google.com' target='_blank'>
            Exemplo 01</a>";

echo '<a href="./paginas/AlunoForm.php"
     class="btn btn-primary">Formulário Aluno</a>';

footer();

?>
